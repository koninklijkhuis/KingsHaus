from ..utils import bitly, xbmcutil
from . import veetle, sopcast

def addStreams():
    pBar = xbmcutil.createProgressBar('Dutch Sports Streams', 'Laden van streams...')

    xbmcutil.updateProgressBar(pBar, msg='Daz Sports 2')
    ds3 = bitly.getLink('daz2')
    veetle.addChannel('DazSports.org - Stream 2', ds3)
	
    xbmcutil.updateProgressBar(pBar, msg='Daz Sports 3')
    ds3 = bitly.getLink('daz3')
    veetle.addChannel('DazSports.org - Stream 3', ds3)

    xbmcutil.updateProgressBar(pBar, msg='Daz Sports 4')
    ds4 = bitly.getLink('daz4')
    veetle.addChannel('DazSports.org - Stream 4', ds4)

    xbmcutil.updateProgressBar(pBar, msg='Daz Sports 5')
    ds5 = bitly.getLink('daz5')
    veetle.addChannel('DazSports.org - Stream 5', ds5)

    xbmcutil.updateProgressBar(pBar, 99, 'DazSports ACE')
    sopcast.addAceStream('Daz Sports ACE', 'http://forum.dazsports.org/Dazsports1.acelive')
	
    xbmcutil.updateProgressBar(pBar, 100,'Gereed!')
    xbmcutil.endOfList()