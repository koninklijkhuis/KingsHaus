from ..utils import bitly, xbmcutil
from . import veetle

def addStreams():
    pBar = xbmcutil.createProgressBar('Dutch Sports Streams', 'Laden van streams...')

    xbmcutil.updateProgressBar(pBar, 33, 'BVLS - Stream 1')
    bvls1 = bitly.getLink('bvls1')
    veetle.addChannel('BVLS - Stream 1', bvls1)

    xbmcutil.updateProgressBar(pBar, 66, 'BVLS - Stream 2')
    bvls2 = bitly.getLink('bvls2')
    veetle.addChannel('BVLS - Stream 2', bvls2)

    xbmcutil.updateProgressBar(pBar, 99, 'BVLS - Stream 3')
    bvls3 = bitly.getLink('bvls3')
    veetle.addChannel('BVLS - Stream 3', bvls3)

    xbmcutil.updateProgressBar(pBar, 100,'Gereed!')
    xbmcutil.endOfList()