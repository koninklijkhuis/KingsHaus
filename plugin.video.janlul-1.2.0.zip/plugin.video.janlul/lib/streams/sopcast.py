from ..utils import xbmcutil, bitly
import urllib2, re

def add13Stream():
    addSopStream('13th Stream 1', '106491')
    addSopStream('13th Stream 2', '106492')
	
def addStreams():
    #addSopStream('13th Stream 1', '106491')
    #addSopStream('13th Stream 2', '106492')
    #addAceStream('Daz Sports ACE (SD)', 'http://forum.dazsports.org/Dazsports1.acelive')
    

    #TEST
    #addAceStream('TEST','')
    foxsports = bitly.resolveTorrentTv('http://torrent-tv.ru/torrent-online.php?translation=9218')
    addAceStream('Fox Sports 2 NL ',foxsports)
    addSopStream('DSC+1', '150004')
    addAceStream('Dazsports','4016bc0b052c0e113ab51d635c66ca1669da0440')
    addAceStream('Dazsports 2','d293c82146aa6c2904e45ff305ae0f38dc5b329d')
    addAceStream('Dazsports 3','6b5c073b86fb29ffc73f47231f30068d223a4d3d')
    addAceStream('YES','8f9ea6a3e2c20cf2c8173b3e9d0795de70a26893')
    addAceStream('Stream Of The Day','27feca99304539891f6a8362a0f14fc0cdb8c24d')

    #addAceStream('Fox Sports 2 NL','0aace26d5d72e71dc09595b24019412240ee4e1a')
    #addAceStream('Fox Sports 2 NL (1)','8feab4017abdbf3601143f004e394092fa63962c')
    #addAceStream('Fox Sports 2 NL (2)','f9eaa074fc596ed58d87456edb87a4017bd06fe6')
    #addAceStream('Fox Sports 2 NL (3)','3d3d76b741ac2b10fa43b9175f82bf354b07dfb1')
    #addAceStream('Fox Sports 2 NL (4)','8931b59fb832ee4abd12686cf544ec31a1574984')
    #addSopStream('M and M 1', '141879')
    #addSopStream('M and M 2', '124892')
    #addSopStream('M and M 3', '124893')
    #addSopStream('M and M 4', '124894')
    #addSopStream('M and M 5', '125815')
    #addSopStream('M and M 6', '125816')
    #addSopStream('M and M 7', '125817')
    #addSopStream('M and M 8', '125818')
    #addSopStream('M and M Low', '141878')
    #addSopStream('M and M Sports', '142402')

def addSopStream(name, SopId='106491'):
    if(checkSopStream(SopId)):
        displayName = '[COLOR green]'+name+'[/COLOR]'
        p2pUrl = 'plugin://plugin.video.p2p-streams/?url='+SopId+'&mode=2&name='+name.replace(' ', '+')
    else :
        displayName = '[COLOR red]'+name+'[/COLOR]'
        p2pUrl = 'plugin.video.janlul/none'
    xbmcutil.addMenuItem(displayName, p2pUrl, 'true')
	
def addAceStream(name, aceId):
    aceUrl = 'plugin://plugin.video.p2p-streams/?url='+aceId+'&mode=1&name='+name.replace(' ', '+')
    xbmcutil.addMenuItem(name, aceUrl, 'true')


def getSopStream(id):
    content = getUrl("http://sopcast.com/chlist.xml")
    tEntries = re.compile('<item>sop://(.+?):3912/'+str(id)+'</item>').findall(content)
    return tEntries[0]
  
def getUrl(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def checkSopStream(id):    
    print 'do check: ' 
    try:
        getSopStream(id)
        return True
    except:
        return False