import sys, urllib2
import xbmcgui, xbmcplugin, xbmc

addon_handle = int(sys.argv[1])

#pDialog = None
_PERCENT_ = 0
progIncrease = 19

def createProgressBar(title,msg):
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(title, msg)
    return pDialog

def updateProgressBar(pDialog, percent=-1, msg=''):
    global _PERCENT_
    if percent == -1:
        percent = _PERCENT_ + progIncrease
    else:
	    logMessage('hardcoded percentage '+str(percent)+'%')
    _PERCENT_ = percent
    pDialog.update(percent,msg)
	
def addMenuItem(strName, strUrl, bIsPlayable='true'):
    li = xbmcgui.ListItem(strName)
    li.setProperty('IsPlayable', bIsPlayable)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=strUrl, listitem=li)

def logMessage(msg):
    xbmc.log(msg)
	
def endOfList():
    xbmcplugin.endOfDirectory(addon_handle)

def getResponse(url):
    try:
        response = urllib2.urlopen(url)
        if response and response.getcode() == 200:
            return response
        else :
            return False
    except:
        return False